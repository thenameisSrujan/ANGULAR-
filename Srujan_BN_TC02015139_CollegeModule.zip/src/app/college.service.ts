import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CollegeService {

  constructor(private http:HttpClient) { }

  API='http://localhost:8085';

  public registerCollege(collegeData : any){
    return this.http.post(this.API+ '/registerCollege', collegeData);
    
  }

  public getCollege(){
    return this.http.get(this.API+'/getColleges');
  }

  public updateCollege(college:any){
    return this.http.put(this.API+'/updateColleges',college); 
  }

  public deleteColleges(id:any){
    return this.http.delete(this.API+'/college?id='+ id);
  }
  

}
